#ifndef _WINDOW_H_
#define _WINDOW_H_

#include <iostream>

#ifdef __APPLE__
// If modern OpenGL replace gl.h with gl3.h
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>
#else
#include <GL/glew.h>
#endif

#include <GLFW/glfw3.h>
#include "Cube.h"
#include "OBJObject.h"


class Window
{
public:
	static int width;
	static int height;
    //static GLfloat size;
	static void initialize_objects();
	static void clean_up();
	static GLFWwindow* create_window(int width, int height);
	static void resize_callback(GLFWwindow* window, int width, int height);
	static void idle_callback();
	static void display_callback(GLFWwindow*);
	static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
    
    static void clearBuffer();
    static void drawPoint(int, int, float, float, float, float);
    static void setModelview(); //C^-1
    static void setProjection(int, int); //P
    static void setViewPort(float, float); //D
    static void rasterize();
    static void resizeCallback(GLFWwindow*, int, int);
    static void displayCallback(GLFWwindow*);
};

#endif
